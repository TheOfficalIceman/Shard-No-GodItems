package youss3f.unaux.com.shardascension.data;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class PlayerAbilityData {

    private final UUID uuid;
    private final List<String> abilityIds;
    private String selectedAbilityId;

    public PlayerAbilityData(UUID uuid, List<String> abilityIds, String selectedAbilityId) {
        this.uuid = uuid;
        this.abilityIds = new ArrayList<>(abilityIds);
        this.selectedAbilityId = selectedAbilityId;
    }

    public UUID getUuid() {
        return uuid;
    }

    public List<String> getAbilityIds() {
        return abilityIds;
    }

    public String getSelectedAbilityId() {
        return selectedAbilityId;
    }

    public void setSelectedAbilityId(String selectedAbilityId) {
        this.selectedAbilityId = selectedAbilityId;
    }
}
